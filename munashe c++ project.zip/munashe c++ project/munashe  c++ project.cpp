#include <iostream>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <conio.h>
#include <iomanip>

using namespace std;
int main()
{
    FILE *fp, *ft;
    char another, choice;

    struct munashe
    {
        char camera[50], model[50];
        int number;
        long cost;
    };

    struct munashe e;
    char camera[50], model[50];
    long int recsize;

    fp=fopen("users.txt","rb+");

    if (fp == NULL)
    {
        fp = fopen("users.txt","wb+");

        if (fp==NULL)
        {
            puts("Cannot open file");
            return 0;
        }
    }



    recsize = sizeof(e);

    while(1)
    {
        system("cls");

        cout << "\t\t  munashe with cameras";
        cout <<"\n\n                                          ";
        cout << "\n\n";
        cout << "\n \t\t\t 1. Enter camera details ";
        cout << "\n \t\t\t 2. Read camera details";
        cout << "\n \t\t\t 3. Update details";
        cout << "\n \t\t\t 4. Delete details";
        cout << "\n \t\t\t 5. Exit";
        cout << "\n\n";
        cout << "\t\t\t Select Your Choice : ";
        fflush(stdin);
        choice = getche();
        switch(choice)
        {
        case '1' :
            fseek(fp,0,SEEK_END);
            another ='Y';
            while(another == 'Y' || another == 'y')
            {
                system("cls");
                cout << "Enter camera name  : ";
                cin >> e.camera;
                cout << "Enter camera model : ";
                cin >> e.model;
                cout << "Enter number of cameras     : ";
                cin >> e.number;
                cout << "Enter cost of camera   : ";
                cin >> e.cost;
                fwrite(&e,recsize,1,fp);
                cout << "\n Add Another Record (Y/N) ";
                fflush(stdin);
                another = getchar();
            }
            break;
        case '2':
            system("cls");
            rewind(fp);
            cout << "=== View the list  ===";
            cout << "\n";
            while (fread(&e,recsize,1,fp) == 1)
            {
                cout << "\n";
                cout <<"\n" << e.camera << setw(10)  << e.model;
                cout << "\n";
                cout <<"\n" <<e.number <<  setw(8)  << e.cost;
            }
            cout << "\n\n";
            system("pause");
            break;

        case '3' :
            system("cls");
            another = 'Y';
            while (another == 'Y'|| another == 'y')
            {
                cout << "\n Enter  camera : ";
                cin >> model;

                rewind(fp);
                while (fread(&e,recsize,1,fp) == 1)
                {
                    if (strcmp(e.camera,model) == 0)
                    {
                        cout << "Enter new camera : ";
                        cin >> e.camera;
                        cout << "Enter new model: ";
                        cin >> e.model;
                        cout << "Enter new number   : ";
                        cin >> e.number;
                        cout << "Enter new cost  : ";
                        cin >> e.cost;
                        fseek(fp, - recsize, SEEK_CUR);
                        fwrite(&e,recsize,1,fp);
                        break;
                    }
                    else
                        cout<<"record not found";
                }
                cout << "\n Modify Another Record (Y/N) ";
                fflush(stdin);
                another = getchar();
            }
            break;


        case '4':
            system("cls");
            another = 'Y';
            while (another == 'Y'|| another == 'y')
            {
                cout << "\n Enter product  to be deleted : ";
                cin >> model;

                ft = fopen("temp.dat", "wb");

                rewind(fp);
                while (fread (&e, recsize,1,fp) == 1)

                    if (strcmp(e.model,model) != 0)
                    {
                        fwrite(&e,recsize,1,ft);
                    }
                fclose(fp);
                fclose(ft);
                remove("users.txt");
                rename("temp.dat","users.txt");

                fp=fopen("users.txt","rb+");

                cout << "\n Delete Another product (Y/N) ";
                fflush(stdin);
                another = getchar();
            }

            break;

        case '5':
            fclose(fp);
            cout << "\n\n";
            cout << "\t\t     THANK YOU!";
            cout << "\n\n";
            exit(0);
        }
    }


    system("pause");
    return 0;
}
